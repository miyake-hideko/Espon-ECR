<?php

// Este archivo contiene el procesamiento de los datos

class status {
	private $bd = array();
    private $conn;
    private $sql;

    public function __construct($bd) {
        $this->bd = $bd;
        $this->connectBD();    
    }
    
    
    public function connectBD(){
        $this->conn = new mysqli($this->bd["servername"], $this->bd["username"], $this->bd["password"], $this->bd["dbname"]);
        // Check connection
        if ($this->conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
    } 

    public function queryBD(){
        $this->result = $this->conn->query($this->sql);
        if ( $this->result === TRUE) {
         return true;
        } else {
            return false;
        }
    }

    public function disconnectBD(){
        $this->conn->close();     
    } 

	public function addStatusPrinter($data) {
       
        $this->sql = "INSERT INTO statusprinter (systemid, offline, cover_open, roll_paper_near_end, habStatus, dateLog)
        VALUES ('" . $data['systemid'] . "'," . $data['offline'] . ", " . $data['cover_open'] . ", " . $data['roll_paper_near_end']  . ", true, DATE_ADD(NOW(), INTERVAL 2 HOUR))
        ON DUPLICATE KEY UPDATE
            offline = " . $data['offline'] . ", 
            cover_open = " . $data['cover_open'] . ",
            habStatus = true,
            dateLog = DATE_ADD(NOW(), INTERVAL 2 HOUR),
            roll_paper_near_end = " . $data['roll_paper_near_end'] ;
            
		return $this->queryBD();
    }
   
}

?>
	