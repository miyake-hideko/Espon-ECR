<?php

    $bd = array(
        "servername" => "localhost",
        "username" => "ESPIGA",
        "password" => "ESPIGA",
        "dbname" => "ESPIGA"  
    );

?>