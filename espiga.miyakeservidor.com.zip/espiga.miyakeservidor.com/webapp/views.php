<?php 
include 'templates/header.php';
?>
            <div class="row">
               <div class="col-md-6">
                  <div class="tile tile-primary">
                     <div class="tile-heading">Impresoras ECR Online</div>
                     <div class="tile-body">
                        <i class="fa fa-users"></i>
                        <h2 class="pull-right" id="numPrinters">0</h2>
                     </div>
                     <div class="tile-footer"></div>
                  </div>
               </div>
               <div class="col-md-6">
                  <div class="tile tile-primary">
                     <div class="tile-heading" id="totalSales">Total Ventas </div>
                     <div class="tile-body">
                        <i class="fa fa-credit-card"></i>
                        <h2 class="pull-right" id="numSales">0</h2>
                     </div>
                     <div class="tile-footer"></div>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-lg-12 col-md-12 col-sm-12">
                  <div class="panel panel-default">
                     <div class="panel-heading">
                        <h3 class="panel-title"><i class="fa fa-bar-chart-o"></i> Análisis de Ventas</h3>
                     </div>
                     <div class="panel-body">
                        <div class="row">
                           <div class='col-sm-2'></div>
                           <div class='col-sm-3 form-group'>
                              <div class="form-group">
                                 <label for="datepickerFrom">Desde</label>
                                 <input type="text"  class="form-control"  id="datepickerFrom" readonly>
                              </div> 
                           </div>
                           <div class='col-sm-2'></div>
                           <div class='col-sm-3 form-group'>
                              <div class="form-group">
                                 <label for="datepickerTo">Hasta</label>
                                 <input type="text" class="form-control"  id="datepickerTo" readonly>
                              </div>
                           </div>
                        </div>
                        <canvas id="canvas" width="100%" height="50%"></canvas>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="container-fluid zone-blue">
         <div class="container">
            <!-- status -->
            <div class="panel panel-default">
               <div class="panel-heading mypadding">
                  <h3 class="panel-title"><i class="fa fa-shopping-cart"></i> Impresoras ECR</h3>
               </div>
               <div class="panel-body mypadding">
                  <div class="table-responsive" style="background-color: white;">
                     <table id='status' class="table table-striped table-bordered table-sm"  >
                        <thead>
                           <tr >
                              <th class="text-center">System ID</th>
                              <th class="text-center">Com. Tienda</th>
                              <th class="text-center">Tapa</th>
                              <th class="text-center">Papel</th>
                              <th class="text-center">Ultima conexion</th>
                              <th class="text-center">Detalles</th>
                           </tr>
                        </thead>
                        <tbody id="statusBody" ></tbody>
                     </table>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="container-fluid zone-white">
         <div class="container">
            <div class="text-center">
               <div id= titlePrinter>
                  <h2>No hay impresora seleccionada</h2>
               </div>
            </div>
            <br>
            <!-- ventas -->
            <div class="panel panel-default">
               <div class="panel-heading mypadding">
                  <h3 class="panel-title"><i class="fa fa-shopping-cart"></i>Actividad reciente (últimas ventas)</h3>
               </div>
               <br>
               <div class="panel-body mypadding">
                  <div class="table-responsive">
                      
                    <div class="form-group row">
                        <label class="col-sm-2 col-form-label" >Tipo de documento: </label>
                        <div class="col-sm-10">
                        <select class="form-control" id="spn_ticket_type">
                            <option value="%">Todos</option>
                            <option value="ticket_basic">Boleta</option>
                            <option value="ticket_invoice">Factura</option>
                            <option value="nfr_receipt_type_pre_ticket">Nota de venta</option>
                            <option value="RA_ticket_basic">Baja de boleta</option>
                            <option value="RA_ticket_invoice">Baja de factura</option>
                        </select>
                        </div>
                    </div>
                      
                     <table id='sales' class="table table-striped table-bordered table-sm" style="width:100%" >
                        <thead>
                           <tr>
                              <th class="text-center">Fecha</th>
                              <th class="text-center">Tipo Doc.</th>
                              <th class="text-center">N°</th>
                              <th class="text-center">Subtotal</th>
                              <th class="text-center">IGV</th>
                              <th class="text-center">ICBPER</th>
                              <th class="text-center">Total</th>
                              <th class="text-center">Pago</th>
                              <th class="text-center">Detalle</th>
                           </tr>
                        </thead>
                        <tbody id="salesBody"></tbody>
                     </table>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <footer>
         <div class="container"><a href="http://miyake.pe">MIYAKE Distribuciones</a></div>
      </footer>
      <!-- Modal -->
      <div id="myItemModal" class="modal fade" role="dialog">
         <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
               <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
               </div>
               <div class="modal-body" id="mainBodyModal">  </div>
               <div class="modal-footer">
                  <button type="button" class="btn btn-primary" data-dismiss="modal">Salir</button>
               </div>
            </div>
         </div>
      </div>
        <div class="modal fade" id="myItemModalPago" tabindex="-1" role="dialog" aria-labelledby="itemModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-m" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="itemModalLabel">Actualizar Pago</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            
                            <input class="form-control" type="text" id="txt_id_update_pago" hidden>
                            
                            <label>Impresora:</label>
                            <input class="form-control" type="text" id="txt_printer_update_pago" readonly>
                            <br>
        
                            <label>ticket_number:</label>
                            <input class="form-control" type="text" id="txt_ticket_number_update_pago" readonly>
                            </select>
                            <br>
        
        
                            <label>Total:</label>
                            <input class="form-control" autocomplete="off" id="txt_gross_amount_update_pago">
                            <br>
        
                            <label>Monto Pago:</label>
                            <input class="form-control" type="text" autocomplete="off" id="txt_pago_update_pago">
                            
                            <label>Motivo*:</label>
                            <input class="form-control" type="text" autocomplete="off" id="txt_motivo_update_pago">
        
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                        <button type="button" class="btn btn-primary"
                            onclick="updatePagoPost()"
                            data-dismiss="modal">Guardar</button>
                    </div>
                </div>
            </div>
        </div>
      <div class="container">
      </div>
      <script>

         // variables globales
         var $timer
         var myIDPrinter = "";
         var habComServer = 0;
         var ticketType = "";
         var dateFrom = "";
         var dateTo = "";

         var datatable = $('#sales').DataTable({"deferRender": true,
                                                "language": {
                                                    "sProcessing":     "",
                                                    "sLengthMenu":     "Mostrar _MENU_ registros",
                                                    "sZeroRecords":    "No se encontraron resultados",
                                                    "sEmptyTable":     "Ningún dato disponible en esta tabla",
                                                    "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                                                    "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
                                                    "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
                                                    "sInfoPostFix":    "",
                                                    "sSearch":         "Buscar:",
                                                    "searchPlaceholder": "Escriba aquí..",
                                                    "sUrl":            "",
                                                    "sInfoThousands":  ",",
                                                    "sLoadingRecords": "<img style='display: block;width:100px;margin:0 auto;' src='assets/img/loading.gif' />",
                                                    "oPaginate": {
                                                        "sFirst":    "Primero",
                                                        "sLast":     "Último",
                                                        "sNext":     "Siguiente",
                                                        "sPrevious": "Anterior"
                                                    },
                                                    "oAria": {
                                                        "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
                                                        "sSortDescending": ": Activar para ordenar la columna de manera descendente"
                                                    }
                                                }
                                            });

         var barChartData  = {
         		labels: [],		
         		datasets: []
         	};
         var color = Chart.helpers.color;
         var ctx;
         
         var dateMin, dateMax;
         var retSales = [];
         						
         // inicializacion de los campos de fecha
         $( "#datepickerFrom" ).datepicker(); 
         $( "#datepickerFrom" ).datepicker("option", "dateFormat", "dd-mm-yy"); 
         $( "#datepickerTo" ).datepicker(); 
         $( "#datepickerTo" ).datepicker("option", "dateFormat", "dd-mm-yy"); 
         
         // conversion de dd-mm-yyyy  a yyyy-mm-dd 
         function getDateFromDateToYear(cadTemp){
         
         	var start, end, resp;
         	
         	start = 0;	
         	end = cadTemp.indexOf("-", start);			
         	var mydate = cadTemp.substring(start, end);
         				
         	start = end + 1;
         	end = cadTemp.indexOf("-", start);			
         	var mymonth = cadTemp.substring(start, end);
         	
         	start = end + 1;
         	end = cadTemp.length;			
         	var myyear = cadTemp.substring(start, end);
         	
         	resp = myyear + "-" + mymonth + "-" + mydate;
         		
         	return resp;			
         }
         	
         
         // conversion de yyyy-mm-dd a dd-mm-yyyy	
         function getDateFromYearToDate(cadTemp){
         
         	var start, end, resp;
         	
         	start = 0;	
         	end = cadTemp.indexOf("-", start);			
         	var myyear = cadTemp.substring(start, end);
         				
         	start = end + 1;
         	end = cadTemp.indexOf("-", start);			
         	var mymonth = cadTemp.substring(start, end);
         	
         	start = end + 1;
         	end = cadTemp.length;			
         	var mydate = cadTemp.substring(start, end);
         	
         	resp = mydate + "-" + mymonth + "-" + myyear;
         		
         	return resp;			
         }
         	
         	
         // obtencion de fecha
         function getDateApp(cad){
         	var monthNames = [ "Jan", "Feb", "Mar", "Apr", "May", "Jun","Jul", "Aug", "Sep", "Oct", "Nov", "Dec" ];
         	var start, end, resp;
         
         	
         	cadTemp = cad.toString();
         			
         	start = cadTemp.indexOf(" ") + 1;	
         	end = cadTemp.indexOf(" ", start);			
         	var mymonth = cadTemp.substring(start, end);
         				
         	start = end + 1;
         	end = cadTemp.indexOf(" ", start);			
         	var mydate = cadTemp.substring(start, end);
         	
         	start = end + 1;
         	end = cadTemp.indexOf(" ", start);			
         	var myyear = cadTemp.substring(start, end);
         	
         	
         	var numMonth;
         	for (var index = 0; index < monthNames.length; ++index) {
         		if (mymonth == monthNames[index]){
         
         			numMonth = "";
         			if ((index + 1) < 10){
         				numMonth = "0";
         			}
         
         			numMonth = numMonth + (index + 1);		
         			break;
         		}
         	}
         
         	resp = mydate + "-" + numMonth + "-" + myyear;		
         	return resp;				
         }	
         
         
         

         window.onload = function() {
            
            this.validarSesion();
            this.obtenerInformacion();
            this.obtenerPermisos();
            
         	Date.prototype.GetFirstDayOfWeek = function() {
         		return (new Date(this.setDate(this.getDate() - this.getDay())));
         	}
         
         	Date.prototype.GetLastDayOfWeek = function() {
         		return (new Date(this.setDate(this.getDate() - this.getDay() +6)));
         	}
         
         	var today = new Date();
         
         	document.getElementById('datepickerFrom').value = getDateApp(today.GetFirstDayOfWeek());
         	document.getElementById('datepickerTo').value = getDateApp(today.GetLastDayOfWeek());
         	
         
         	ctx = document.getElementById('canvas').getContext('2d');
         	window.myBar = new Chart(ctx, {
         		type: 'bar',
         		data: barChartData,
         		options: {
         			responsive: true,
         			legend: {
         				position: 'top',
         			},
         			title: {
         				display: true,
         				text: 'VENTAS X EQUIPO ' 
         			}
         		}
         	});
         	
         	getData(); 
         	
         	             
            dateFrom = '';
            dateTo = '';
         	
         	// timer para refrescar el pantalla cada 1 segundo
         	$timer = setInterval(getData, 1000);

         };
         
         function getData() {
            
            getStatus();
         	getTotals();

         	if (myIDPrinter !== ""){

                var ticket_type = document.getElementById('spn_ticket_type').value;
                
                if(ticket_type !== ticketType){
                    consultaTique(myIDPrinter, ticket_type);
                    ticketType = ticket_type;
                }

            }
         }
         
         // consulta al servidor el status de cada impresora
         function getStatus(){
         $.ajax({
         	url: "system/ajax-php/status.php",
         	type:"GET",
         	success: function(val){
         		var		online =   '<div class="alert-online">';
         		var		offline =   '<div class="alert-offline">';
         		var 	systemID, alias, tienda, tapa, papel, fecha;
         		var  	numPrinters = 0;	
         		var   	cad = "";
         
         		for (i in val['printers']) {
         	
         				numPrinters = numPrinters + 1;
         				
         				systemID = val['printers'][i].systemid;

         				if(val['printers'][i].alias == null)
         				    alias = '';
         				else
         				    alias = val['printers'][i].alias;         				

         				tienda = offline   + 'Offline';
         				if (val['printers'][i].offline == "0"){
         					tienda = online + 'Online';
         				}
         				
         				tapa = online + 'Cerrada';
         				if (val['printers'][i].cover_open == "1"){
         					tapa = offline + 'Abierta';
         				}
         				
         				papel = online + 'OK';
         				if (val['printers'][i].roll_paper_near_end == "1"){
         					papel = offline + 'Poco';
         				}
         				
         				fecha= val['printers'][i].dateLog;

         				aux = '<td >' +  systemID + ' ' + alias + '</td>';
         				aux = aux + '<td align="center"> ' + tienda + '</div></td>';
         				aux = aux + '<td align="center">' + tapa + '</div></td>';
         				aux = aux + '<td align="center">' + papel + '</div></td>';
         				aux = aux + '<td align="center"><b>' + fecha + '</b></td>';
         				aux = aux + '<td align="center"><button class="btn btn-primary" type="button" onclick="setPrinter(\'' + systemID + '\',\'' + alias + '\')"><i class="fa fa-eye"></i></button></td>';
         			    
         			    aux = aux + '</td>';
         
         				cad = cad + '<tr ">' + aux + '</tr>';
         		}	
         
         
         		if (numPrinters > 0){
         			document.getElementById("statusBody").innerHTML = cad;
         			document.getElementById('numPrinters').innerHTML = numPrinters;	
         		}	
         		
         	}
         }); 
         				
         };
         
         
         // consulta al servidor el total de cada impresora para ser graficados
         function getTotals(){
         
             // get data from server
             dateMin = getDateFromDateToYear(document.getElementById('datepickerFrom').value);
             dateMax = getDateFromDateToYear(document.getElementById('datepickerTo').value);
             
             if(dateMin === dateFrom && dateMax === dateTo){
                 return;
             }
             
             dateFrom = dateMin;
             dateTo = dateMax;

                 $.ajax({
                 	url: "system/ajax-php/totals.php?dateMin=" + dateMin + "&dateMax=" + dateMax,
                 	success: function(val){
                 			
                 		var habChanges = false;
                 		while(true){
                 		
                 			if (retSales.length == 0){
                 				habChanges = true;
                 				break;
                 			}
                 		
                 		
                 	
                 			if (retSales['dates'].length != val['dates'].length){
                 				habChanges = true;
                 				break;
                 			}
                 		
                 			for (i in val['dates']) {
                 				if (retSales['dates'][i] != val['dates'][i]){
                 					habChanges = true;
                 					break;
                 				}
                 			}	
                 			if (habChanges) break;
                 
                 
                 			if (retSales['printers'].length != val['printers'].length){
                 				habChanges = true;
                 				break;
                 			}
                 
                 			for (i in val['printers']) {
                 							
                 				if (retSales['printers'][i].systemid != val['printers'][i].systemid){ //dataSet
                 					habChanges = true;
                 					break;
                 				}
                 			
                 				if (retSales['printers'][i]['values'].length != val['printers'][i]['values'].length){
                 					habChanges = true;
                 					break;
                 				}
                 
                 				for (x in val['printers'][i]['values']) { // values
                 					if (retSales['printers'][i]['values'][x] != val['printers'][i]['values'][x]){
                 						habChanges = true;
                 						break;
                 					}
                 				}
                 				if (habChanges) break;
                 			
                 			}
                 				
                 			
                 			break;
                 		}
                 		
                 		
                 		if (habChanges){
                 			setLabels(val['dates']);
                 			setDataSet(val['printers']);
                 		}
                 			
                 		habChanges = habChanges;	
                 	
                 	}
                 	
                 	
                 }); 	

         }
         
         
         function setPrinter(idPrint, alias){
             document.getElementById('titlePrinter').innerHTML = '<h2>Impresora: '  + idPrint + ' ' + alias + '</h2>';
             
             myIDPrinter = idPrint;
             ticketType = "%";
             consultaTique(idPrint, ticketType);

         }

         // muestra el tique en pantalla
         function showTicket(idPrinter, ticket_number, ticket_type){
         
         	$.ajax({
         		url: "system/ajax-php/ticket.php?systemid=" + idPrinter + '&ticket_number=' + ticket_number  + '&mode=view' + '&ticket_type=' + ticket_type,
         		type:"GET",
         		success: function(val){
         			var cad = "";
         
         			if (val['status'] == 0){

         				// datos de empresa
             				cad = "<p class='text-center'><b>" + val['fiscaldata'][0].business_name + " </b></p>";
             				cad = cad + "<p class='text-center'> RUC: " + val['fiscaldata'][0].tributary_id + " </p>";
             				
             				if(val['fiscaldata'][0].business_address !== null)
             				    cad = cad + "<p class='text-center'>" + val['fiscaldata'][0].business_address + " </p>";
             				
             				cad = cad + "<hr>";
         				
         				// datos de cliente
         				
                            if(val['ticket'][0].customer_id !== null){
                                  
                                if(ticket_type == "ticket_basic"){
                                    cad = cad + "<b>DNI: </b>" +  val['ticket'][0].customer_id + " </p>";
                                    cad = cad + "<b>Cliente: </b>" +  val['ticket'][0].customer_name + " </p>";  
                                }
                                else if(ticket_type == "ticket_invoice"){
                                    cad = cad + "<b>RUC: </b>" +  val['ticket'][0].customer_id + " </p>";
                                    cad = cad + "<b>RAZÓN SOCIAL: </b>" + val['ticket'][0].customer_name + " </p>";       
                                }
                    
                             	cad = cad + "<hr>";
                            }
         				
         				
         				// datos de tique
         				var temp = val['ticket'][0].datetime;
         				var date = temp.substring(0, 10);
         				var time = temp.substring(11, temp.length);
         		
         				cad = cad + "<p><div class = 'myLeft'><b>" + "Nro Ticket:</b></div><div class = 'myRight'> " + ticket_number + "</div></p>";
         				cad = cad + "<p><div class = 'myLeft'><b>Cajero:</b></div><div class = 'myRight'> " + val['ticket'][0].cashier_name + "</div></p>";
         				cad = cad + "<p><div class = 'myLeft'><b>Fecha: </b>" +  date   + "</div><div class = 'myRight'> " +   "<b>Hora: </b>" + time +   "</div></p>";
         				cad = cad + "<hr>";											

         				// datos de productos
         				for (i in val['items']) {
         
         					if (val['items'][i].quantity == 0 ){
         					    continue;
         					}
         					
         					cad = cad + "<p>" + val['items'][i].quantity + " x S/." + val['items'][i].unit_price + "</p>";		
         					
         					cad = cad + "<p><div class = 'myLeft'>"  + val['items'][i].description + "</div><div class = 'myRight'>"  +  val['items'][i].gross_amount +  "</div></p>";		
         		
         				}		
         
         				cad = cad + "<hr>";
         
         				//total
         				cad = cad + "<p><div class = 'myLeft'><b>Subtotal:</b></div><div class = 'myRight'> " + val['ticket'][0].subtotal + "</div></p>";
         				cad = cad + "<p><div class = 'myLeft'><b>IGV:</b></div><div class = 'myRight'> " + val['ticket'][0].vat_amount + "</div></p>";
         				cad = cad + "<p><div class = 'myLeft'><b>ICBPER:</b></div><div class = 'myRight'> " + val['ticket'][0].bag_tax_amount + "</div></p>";
         				cad = cad + "<p><div class = 'myLeft'><b>Total:</b></div><div class = 'myRight'> " + val['ticket'][0].gross_amount + "</div></p>";
         				
         				cad = cad + "<hr>";
         
         			
         			    // payments
         			    for (i in val['payments']) {
         					cad = cad + "<p><div class = 'myLeft'>" + val['payments'][i].description + "</div><div class = 'myRight'>" +  val['payments'][i].amount + "</div></p>";
         				}	
         				
         				cad = cad + "<hr>";         				
         				cad = cad + "<p><div class = 'myLeft'><b></b></div><div class = 'myRight'> Registro Nro: " + val['ticket'][0]['rec_num'] + "</div></p>";

         				document.getElementById("mainBodyModal").innerHTML = cad;
         				$("#myItemModal").modal();
         			}
         			else{
         				alert(val['message']);
         			}	
         		},
         		error: function(val){
                 alert("No fue posible obtener datos del ticket");
             	}
         	}); 
         

         }
         
         
         // descarga de tique
         function downloadTicket(idPrinter, ticket_number, ticket_type){
         
         var path = "system/ajax-php/ticket.php?systemid=" + idPrinter + '&ticket_number=' + ticket_number +  '&mode=download' + '&ticket_type=' + ticket_type;	 		
         window.open( path);
         
         }
         
         //INICIO
         
         function updatePago(idPrinter, ticket_number, ticket_type, gross, pago, idTicket, motivo){
            
            document.getElementById("txt_id_update_pago").value = idTicket;
            document.getElementById("txt_printer_update_pago").value = idPrinter;
            document.getElementById("txt_ticket_number_update_pago").value = ticket_number;
            document.getElementById("txt_gross_amount_update_pago").value = gross;
            document.getElementById("txt_pago_update_pago").value = pago;
            document.getElementById("txt_motivo_update_pago").value = motivo;
         }
         
         function updatePagoPost(){
             
            
            
            
             
            var idticket = document.getElementById("txt_id_update_pago").value; 
            var pago = document.getElementById("txt_pago_update_pago").value; 
            var motivo = document.getElementById("txt_motivo_update_pago").value; 
            //validacion
            if (motivo == ""){
                
                swal({
                        title: "Alerta!",
                        text: "El campo motivo no puede estar vacio",
                })
                
            return;
                
            }
             
            $.ajax({

                url: "system/ajax-php/ticket.php?idticket=" + idticket +
                                                "&pago=" + pago +
                                                "&motivo=" + motivo +
                                                "&systemid=1" + 
                                                "&ticket_number=1" + 
                                                "&ticket_type=1" + 
                    '&mode=updatePago',
                type: "GET",
                success: function(val) {
            
                    var message;
                    message = val['message'].message;
            
                    swal({
                        title: "Alerta!",
                        text: message,
                    })
            
            
                }
            
            });
             
         }
         
         //FIN 
         
         
         
         // consulta al servidor los tiques de la impresora seleccionada
         function consultaTique(idPrint, ticket_type){
             console.log("consultaTique");
         $.ajax({
         	url: "system/ajax-php/sales.php?systemid=" + idPrint  + "&datebegin=" + dateMin + "&dateend=" + dateMax + "&ticket_type=" + ticket_type + '&mode=view',
         	type:"GET",
         	success: function(val){
         	    
         	    console.log(val);
         	    
         	    datatable.destroy();
         	    
         		var cad = "";
         		var conditional_pay = "";
         		for (i in val['printers']) {
         		    
         			aux = '';
         			conditional_pay = "";
         			// ---------------- INICIO PAGO --------------
         			// Solo realizar el calculo si es cheque, se usa el campo gross_amount para compararlo con el pago
         			if ( val['printers'][i].description == "Cheque" ) {
         			    
         			    var pago_parse = parseFloat(val['printers'][i].pago);
         			    var gross_parse = parseFloat(val['printers'][i].gross_amount);
         			    
         			    if (pago_parse == gross_parse ) {
         			        
         			        conditional_pay = 'Cancelado';
         			        
         			    } else {
         			        
         			        conditional_pay = 'Sin Cancelar';
         			        
         			    }
         			    
         			    
         			} else {
         			    
         			    conditional_pay = 'Cancelado';
         			    
         			}
                    // ---------------- FIN PAGO --------------
         			
         			aux = '<td align="center"><b>' + val['printers'][i].datetime + '</b></div></td>';

             		var $ticket_type_temp =  val['printers'][i].ticket_type;         		
             		if ($ticket_type_temp == "ticket_basic"){
                            $ticket_type_temp = "Boleta";    
                    } else if ($ticket_type_temp == "ticket_invoice"){
                            $ticket_type_temp = "Factura"; 
                    } else if ($ticket_type_temp == "nfr_receipt_type_pre_ticket"){
                            $ticket_type_temp = "Nota de venta";                         
                    } else if ($ticket_type_temp == "RA_ticket_basic"){
                            $ticket_type_temp = "RA/Boleta";    
                    } else if ($ticket_type_temp == "RA_ticket_invoice"){
                            $ticket_type_temp = "RA/Factura";    
                    }   
                    
                    var $cancel_reason_temp =  val['printers'][i].cancel_reason;    
                    if ($cancel_reason_temp != "" && 
                        $ticket_type_temp != "RA/Boleta" &&
                        $ticket_type_temp != "RA/Factura"){
                            $ticket_type_temp += "/Anulada";
                    }

                    if ($ticket_type_temp == "RA/Boleta" ||
                        $ticket_type_temp == "RA/Factura"){
                        $ticket_type_temp += val['printers'][i].cancelTicket;
                    } 

         			aux = aux + '<td align="center ">' +  $ticket_type_temp + '</div></td>';
         			aux = aux + '<td align="center ">' +  val['printers'][i].ticket_number + '</td>';
         			aux = aux + '<td align="center">' + val['printers'][i].subtotal + '</div></td>';
         			aux = aux + '<td align="center">' + val['printers'][i].vat_amount + '</div></td>';
         			aux = aux + '<td align="center">' + val['printers'][i].bag_tax_amount + '</div></td>';
         			aux = aux + '<td align="center">' + val['printers'][i].gross_amount + '</div></td>';
         			aux = aux + '<td align="center">' + conditional_pay + '</div></td>';
         			aux = aux + '<td class="text-center" >';

                    if ($ticket_type_temp.substring(0, 3) == "RA/"){
                 			aux = aux + '<button class="btn btn-primary" type="button" disabled onclick="showTicket(\'' + idPrint  + '\',' + val['printers'][i].ticket_number + ',\'' + val['printers'][i].ticket_type + '\')" title="vista"><i class="fa fa-eye"></i></button>';
                 			aux = aux + ' ';
                 			aux = aux + '<button class="btn btn-info" type="button" disabled onclick="downloadTicket(\'' + idPrint  + '\',' + val['printers'][i].ticket_number + ',\'' + val['printers'][i].ticket_type + '\')" title="descarga"><i class="fa fa-download"></i></button>';
                 			aux = aux + '</td>';
                    } else {
                 			aux = aux + '<button class="btn btn-primary" type="button" onclick="showTicket(\'' + idPrint  + '\',' + val['printers'][i].ticket_number + ',\'' + val['printers'][i].ticket_type + '\')" title="vista"><i class="fa fa-eye"></i></button>';
                 			aux = aux + ' ';
                 			aux = aux + '<button class="btn btn-info" type="button" onclick="downloadTicket(\'' + idPrint  + '\',' + val['printers'][i].ticket_number + ',\'' + val['printers'][i].ticket_type + '\')" title="descarga"><i class="fa fa-download"></i></button>';
                 			aux = aux + ' ';
                 			if ( val['printers'][i].description == "Cheque" ) {
                 			    aux = aux + '<button class="btn btn-success" type="button" onclick="updatePago(\'' + idPrint  + '\',' + val['printers'][i].ticket_number + ',\'' + val['printers'][i].ticket_type + '\',' + val['printers'][i].gross_amount + ',' + val['printers'][i].pago + ',' + val['printers'][i].Id + ',\''+  val['printers'][i].motivo + '\')" title="Modificar Pago" data-toggle="modal" data-target="#myItemModalPago"><i class="fa fa-cc"></i></button>';
                 			}
                 			
                 			aux = aux + '</td>';
                 			
                    }
         			
         			cad = cad  + '<tr>' + aux + '</tr>';
         		}
         		document.getElementById("salesBody").innerHTML = cad;

                datatable = $('#sales').DataTable({"deferRender": true,
                                                    "language": {
                                                        "sProcessing":     "",
                                                        "sLengthMenu":     "Mostrar _MENU_ registros",
                                                        "sZeroRecords":    "No se encontraron resultados",
                                                        "sEmptyTable":     "Ningún dato disponible en esta tabla",
                                                        "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                                                        "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
                                                        "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
                                                        "sInfoPostFix":    "",
                                                        "sSearch":         "Buscar:",
                                                        "searchPlaceholder": "Escriba aquí..",
                                                        "sUrl":            "",
                                                        "sInfoThousands":  ",",
                                                        "sLoadingRecords": "<img style='display: block;width:100px;margin:0 auto;' src='assets/img/loading.gif' />",
                                                        "oPaginate": {
                                                            "sFirst":    "Primero",
                                                            "sLast":     "Último",
                                                            "sNext":     "Siguiente",
                                                            "sPrevious": "Anterior"
                                                        },
                                                        "oAria": {
                                                            "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
                                                            "sSortDescending": ": Activar para ordenar la columna de manera descendente"
                                                        }
                                                    }
                                                });

         	}
         	,error: function(XMLHttpRequest, textStatus, errorThrown) { 
         	    console.log("Status: " + textStatus); console.log("Error: " + errorThrown); 
                } 
         }); 
                  	
         }

         // adiciona impresora al grafico
         function addPrinterbar(data){
         
         // agreaga la impresora en caso de no exitir 
         var colorNames = Object.keys(window.chartColors);
         var colorName = colorNames[barChartData.datasets.length % colorNames.length];
         var dsColor = window.chartColors[colorName];
         
         var newDataset = {
         	label: data.systemid,
         	backgroundColor: color(dsColor).alpha(0.5).rgbString(),
         	borderColor: dsColor,
         	borderWidth: 1,
         	data: []
         };
         		
         		
         for (var index = 0; index < data.values.length; ++index) {
         		newDataset.data.push(data.values[index]);
         }
         	
         barChartData.datasets.push(newDataset);
         				
         }
         
         // Elimina impresora del grafico
         function delPrinterbar(data){
         var habDel;
         	
         for (var indexChar = 0; indexChar < barChartData.datasets.length; ++indexChar) {
         	habDel = true;
         	for (var index = 0; index < data.length; ++index) {
         		if (barChartData.datasets[indexChar].label == data[index].systemid ){
         			habDel = false;
         			break;
         		}
         	}
         	
         	if (habDel){ 
         		barChartData.datasets.splice(indexChar, 1);
         	}
         }
         }
         
         // obtiene el total acumulado de todas las impresoras graficadas
         function setTotals(data){
         var total = 0;
         
         for (var index = 0; index < data.length; ++index){
         	for (var indexData = 0; indexData < data[index].values.length; ++indexData) {
         		total = total + parseFloat(data[index].values[indexData]);
         	}				
         }	
         	
         document.getElementById("numSales").innerHTML = total.toFixed(2);
         }
         
         // edita las fechas en el grafico
         function setLabels(dataServer){
         
         barChartData.labels = [];
         for (var index = 0; index < dataServer.length; ++index) {
         	barChartData.labels.push(getDateFromYearToDate(dataServer[index]));
         }
         
         }
         
         // edita las impresoras en el grafico
         function setDataSet(dataServer){
         
         var habAdd;
         
         for (var index = 0; index < dataServer.length; ++index) {
         	
         	habAdd = true;
         	for (var indexChar = 0; indexChar < barChartData.datasets.length; ++indexChar) {
         		
         		if (barChartData.datasets[indexChar].label == dataServer[index].systemid ){
         			// edit data
         			barChartData.datasets[indexChar].data = [];
         			for (var indexData = 0; indexData < dataServer[index].values.length; ++indexData) {
         				barChartData.datasets[indexChar].data[indexData] = dataServer[index].values[indexData];
         			}
         			habAdd = false;
         			break;
         		}
         	}
         	
         	if (habAdd){ // new printer
         		addPrinterbar(dataServer[index])
         	}
         	
         }
         	
         // delete
         delPrinterbar(dataServer);
         
         setTotals(dataServer);
         	
         window.myBar.update();
         	
         }



      </script> 
<?php
    include 'templates/footer.php';
?>